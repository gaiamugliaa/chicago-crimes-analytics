from pathlib import Path
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns
from backend import Backend

# Impostazione della pagina
st.set_page_config(
    page_title="Progetto Big Data Chicago",
    layout="wide",
    initial_sidebar_state="expanded" #inizialmente la sidebar aperta per rendere subito visibili le sezioni
)

#personalizza colori, font, titolo, bordo della sidebar e visibilità di alcune parti dell'interfaccia
st.markdown("""
<style>
    footer {visibility: hidden;}
    .stDeployButton {display: none;}
    [data-testid="stSidebar"] {border-right: 1px solid #ffb6c1;}
    h1 {
        color: #d81b60 !important;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        text-align: center;
        border-bottom: 2px solid #ffb6c1;
        padding-bottom: 15px;
        margin-bottom: 30px;
    }
    h2, h3 {
        color: #c2185b !important;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
</style>
""", unsafe_allow_html=True)

st.title("Sistema Distribuito per l'Analisi Avanzata e Predittiva delle Dinamiche Criminali (Chicago)")

# Cerchiamo il CSV accanto ai file Python, così funziona anche su altri PC.
cartella = Path(__file__).resolve().parent #file è il percorso completo di main.py, parent è la cartella che lo contiene, resolve lo rende assoluto e path unisce cartella e nome csv
path = cartella / "Crimes_-_2001_to_Present.csv"
if not path.is_file():
    st.error("Non trovo il CSV. Estrai Crimes_-_2001_to_Present.csv e mettilo "
             "nella stessa cartella di main.py e backend.py.")
    st.stop()

# Streamlit riesegue lo script quando clicchiamo i menu.
# Conserviamo quindi la stessa sessione Spark nella sessione web.
#Quindi i valori salvati in st.session_state sopravvivono ai rerun dwlla stessa sessione web, ma non a chiusura del browser o refresh della pagina.
if "back" not in st.session_state:
    st.session_state.back = Backend()

with st.spinner("⏳ Preparazione dati con Spark..."):
    df = st.session_state.back.load_data(str(path)) #la variabile locale df viene ricostruita ad ogni rerun, ma il dataset Spark resta in st.session_state.back

st.sidebar.markdown("### Navigazione Principale")
st.sidebar.info("💡 Scegli un'analisi dal menu.")
menu = st.sidebar.radio("Seleziona sezione", [ #widget radio: l'utente può selezionare solo una voce alla volta, il valore selezionato viene salvato in menu
    "Top 10 Crimini",
    "Distribuzione Oraria",
    "Clustering K-Means",
    "Confronto Distretti",
    "Predizione Arresto (Random Forest)",
    "ML Ottimizzato (Cross-Validation)",
    "Analisi PCA",
    "Media Mobile"
], label_visibility="collapsed")

st.sidebar.caption("Dataset storico Chicago Crimes · campione casuale del 15%")


# ----------------------- QUERY 1 -----------------------
if menu == "Top 10 Crimini":
    st.header("Classifica delle Tipologie di Reato")
    st.write("Quali categorie di reato compaiono più spesso nel campione?")
    with st.spinner("Calcolo classifica..."):
        res = st.session_state.back.get_top_10_crimes(df)
    st.table(res) #mostra una tabella statica
    fig, ax = plt.subplots(figsize=(9, 5))
    sns.barplot(data=res, x="count", y="Primary Type", ax=ax, color="#d81b60") #disegna un grafico a barre orizzontali, x=conteggio, y=tipo di reato
    ax.set(xlabel="Eventi nel campione", ylabel="Tipologia di reato") #ax area del grafico, set imposta le etichette degli assi
    fig.tight_layout() #prova a sistemare margine ed etichette per evitare che si sovrappongano
    st.pyplot(fig) #rende la figura visibilke nella pagina
    plt.close(fig) #chiude la figura per liberare memoria, altrimenti con più grafici si accumulano e rallentano
    st.caption("I conteggi si riferiscono al campione del 15%, non all'intero archivio.")


# ----------------------- QUERY 2 -----------------------
elif menu == "Distribuzione Oraria":
    st.header("Distribuzione Oraria")
    st.write("Come si distribuiscono gli eventi registrati durante le 24 ore?")
    with st.spinner("Calcolo distribuzione oraria..."):
        res = st.session_state.back.get_hourly_distribution(df)
    st.line_chart(res.set_index("Hour")["count"]) #disegna una serie o più serie temporali, l'asse x è l'indice del dataframe, l'asse y è il valore della colonna count
    #streamlit costruisce direttamente un grafico a linee. E' una distribuzione aggregata per ora, n0on una serie di eventi accaduti in un giorno in particolare. Perciò non ha senso usare un grafico a dispersione (scatter) con punti singoli.
    st.caption("È una distribuzione aggregata, non una previsione dei crimini futuri.")


# ----------------------- CLUSTERING -----------------------
elif menu == "Clustering K-Means":
    st.header("Machine Learning: Profili dei Distretti")
    st.write("Domanda: quali distretti hanno una **composizione dei reati simile**? "
             "Confrontiamo la percentuale di furti, aggressioni, rapine "
             "ed eventi notturni.")

    #il pulsante restituisce true nel rerun causato dal clic; al rerun successivo non riamane true. perciò il risultato 
    # viene salvato in st.session_state in modo che il grafico resti visibile anche dopo il rerun.
    if st.button("Calcola i cluster", key="start_kmeans"):
        with st.spinner("Clustering K-Means in esecuzione..."):
            st.session_state["kmeans_results"] = st.session_state.back.run_kmeans(df)

    if "kmeans_results" in st.session_state:
        result = st.session_state["kmeans_results"]
        st.success(f"Numero di cluster scelto: {result['best_k']}") #segnala un calcolo compoletato

        # ----------------------------------------------------
        # GRAFICO 1 - SILHOUETTE PER K=2,3,4
        # ----------------------------------------------------
        #il dizionario dei punteggi silhouette viene trasformato in un dataframe ordinato per k, così da poterlo graficare.
        scores = pd.DataFrame([
            {"k": int(k), "silhouette": float(v)}
            for k, v in sorted(result["silhouette"].items())
        ])

        st.subheader("Qualità del clustering: confronto della silhouette")
        st.write("Il valore più alto indica la migliore separazione media "
                 "dei gruppi **fra i valori di k provati**.")

        #un colore speciale per il k migliore, un colore neutro per gli altri. La barra più alta è evidenziata.
        colori_barre = [
            "#c2185b" if k == result["best_k"] else "#4d80ae"
            for k in scores["k"]
        ]
        fig, ax = plt.subplots(figsize=(9, 4.2))
        fig.patch.set_facecolor("#fffafb")
        ax.set_facecolor("#fffafb")

        barre = ax.bar(
            scores["k"].astype(str), scores["silhouette"],
            color=colori_barre, width=0.55
        )
        for barra, valore in zip(barre, scores["silhouette"]):
            ax.annotate(
                f"{valore:.3f}",
                (barra.get_x() + barra.get_width() / 2, valore),
                xytext=(0, 6 if valore >= 0 else -14),
                textcoords="offset points",
                ha="center", fontsize=11, fontweight="bold"
            )
        ax.set_title("Confronto della silhouette", fontweight="bold")
        ax.set_xlabel("k (numero di cluster)")
        ax.set_ylabel("Silhouette media")
        ax.set_ylim(
            min(0.0, float(scores["silhouette"].min()) - 0.1),
            min(1.05, max(0.2, float(scores["silhouette"].max()) + 0.15))
        )
        ax.grid(axis="y", alpha=0.18) #grid orizzontale per leggere meglio le altezze delle barre
        ax.set_axisbelow(True)
        sns.despine(ax=ax) #despine rimuove i bordi superiore e destro del grafico, per un aspetto più pulito
        fig.tight_layout()
        st.pyplot(fig)
        plt.close(fig)

        # ----------------------------------------------------
        # GRAFICO 2 - HEATMAP DEL PROFILO MEDIO DEI CLUSTER
        # ----------------------------------------------------
        colonne = ["quota_furti", "quota_battery", "quota_rapine", "quota_notte"]
        nomi = {
            "quota_furti": "Furti",
            "quota_battery": "Aggressioni",
            "quota_rapine": "Rapine",
            "quota_notte": "Eventi notturni"
        }
        mean_profile = ( #calcola la media dei valori di furti, aggressioni, rapine ed eventi notturni per ciascun cluster, ordinando 
            # i cluster per indice e rinominando le colonne con nomi più leggibili
            result["data"].groupby("prediction")[colonne]
            .mean().sort_index().rename(columns=nomi)
        )
        mean_profile.index = [f"Cluster {int(k)}" for k in mean_profile.index]

        st.subheader("Composizione media dei reati per cluster")
        st.write("I colori più intensi rappresentano percentuali più alte. "
                 "Ogni riga descrive il profilo medio dei distretti appartenenti al cluster.")

        fig, ax = plt.subplots(figsize=(10, 4.6))
        fig.patch.set_facecolor("#fffafb")
        sns.heatmap( #una riga per cluster, una colonna per tipologia di reato, con i valori medi percentuali all'interno delle celle (colori piu intensi per valori più alti)
            mean_profile,
            cmap="Blues",
            annot=True, #mostra anche i valori nuerici all'interno delle celle
            fmt=".1f",
            linewidths=1,
            linecolor="white",
            cbar_kws={"label": "Percentuale (%)"},
            ax=ax
        )
        # Migliora il contrasto delle cifre sulle celle blu più scure.
        soglia = (float(mean_profile.values.min()) + float(mean_profile.values.max())) / 2
        for etichetta in ax.texts:
            valore = float(etichetta.get_text())
            etichetta.set_color("white" if valore >= soglia else "#203047")
            etichetta.set_fontweight("bold")
        ax.set_xlabel("")
        ax.set_ylabel("")
        ax.set_title("Profilo medio dei cluster (%)", fontweight="bold", pad=14)
        ax.tick_params(axis="x", rotation=0)
        ax.tick_params(axis="y", rotation=0)
        fig.tight_layout()
        st.pyplot(fig)
        plt.close(fig)

        # ----------------------------------------------------
        # GRAFICO 3 - DISTRETTI COLORATI PER CLUSTER
        # ----------------------------------------------------
        st.subheader("Distretti suddivisi nei gruppi individuati")
        st.write("Ogni punto rappresenta un distretto. I colori indicano il cluster assegnato dall'algoritmo K-Means.")

        punti = result["data"].copy()
        punti["Cluster"] = punti["prediction"].apply(lambda k: f"Cluster {int(k)}")
        valori_cluster = sorted(punti["Cluster"].unique())
        palette_base = ["#c2185b", "#4682b4", "#2a9d8f", "#d49738"]
        palette_cluster = {
            c: palette_base[i % len(palette_base)]
            for i, c in enumerate(valori_cluster)
        }

        fig, ax = plt.subplots(figsize=(10, 6))
        fig.patch.set_facecolor("#fffafb")
        ax.set_facecolor("#fffafb")
        sns.scatterplot(
            data=punti,
            x="quota_furti",
            y="quota_notte",
            hue="Cluster",
            palette=palette_cluster,
            s=130,
            edgecolor="white",
            linewidth=1,
            ax=ax
        )
        for _, riga in punti.iterrows():
            ax.annotate(
                str(int(riga["District"])),
                (riga["quota_furti"], riga["quota_notte"]),
                xytext=(5, 4), textcoords="offset points", fontsize=9
            )
        ax.set_xlabel("Percentuale di furti (%)")
        ax.set_ylabel("Percentuale di eventi notturni (%)")
        ax.set_title("Distretti e cluster assegnati", fontweight="bold")
        ax.legend(title="Gruppo", loc="best")
        ax.grid(alpha=0.15)
        sns.despine(ax=ax)
        fig.tight_layout()
        st.pyplot(fig)
        plt.close(fig)
        st.caption("Il grafico mostra solo due delle quattro caratteristiche usate "
                   "da K-Means: anche aggressioni e rapine contribuiscono al clustering.")

        # I valori esatti restano consultabili, ma non dominano la pagina.
        with st.expander("Mostra le tabelle con tutti i valori numerici"):
            st.write("**Punteggi silhouette**")
            st.dataframe(scores.round(3), hide_index=True, use_container_width=True)
            st.write("**Profili medi dei cluster (%)**")
            st.dataframe(mean_profile.round(1), use_container_width=True)
            st.write("**Distretti e cluster assegnati**")
            st.dataframe(result["data"], hide_index=True, use_container_width=True)

        st.caption("Le quote descrivono le percentuali di eventi registrati. "
                   "I cluster non rappresentano classifiche di pericolosità.")


# ----------------------- QUERY 3 -----------------------
elif menu == "Confronto Distretti":
    st.header("Confronto tra un Distretto e la Città")
    st.write("Questa query mostra quali tipologie di reato sono **relativamente più "
             "rappresentate** in un distretto rispetto alla media cittadina.")
    if "district_options" not in st.session_state:
        with st.spinner("Recupero distretti..."):
            st.session_state.district_options = st.session_state.back.get_districts(df)
    selected = st.selectbox("Seleziona il distretto", st.session_state.district_options)
    with st.spinner("Confronto delle frequenze..."):
        res = st.session_state.back.get_district_comparison(df, selected)

    if res.empty:
        st.warning("Nessun dato disponibile per il distretto selezionato.")
    else:
        # GRAFICO 1: le percentuali consentono di confrontare territori
        # con un numero assoluto di eventi molto diverso.
        st.subheader(f"Composizione dei reati: distretto {selected} e città")
        grafico = res.sort_values("% distretto", ascending=True).copy()
        fig, ax = plt.subplots(figsize=(10, 6))
        fig.patch.set_facecolor("#fffafb")
        ax.set_facecolor("#fffafb")
        pos = list(range(len(grafico)))
        ax.barh([p - 0.18 for p in pos], grafico["% distretto"],
                height=0.34, color="#c2185b", label=f"Distretto {selected}")
        ax.barh([p + 0.18 for p in pos], grafico["% città"],
                height=0.34, color="#4d80ae", label="Città")
        ax.set_yticks(pos)
        ax.set_yticklabels(grafico["Primary Type"])
        ax.set_xlabel("Percentuale sul totale degli eventi (%)")
        ax.set_title("Confronto tra distribuzioni percentuali", fontweight="bold")
        ax.legend()
        ax.grid(axis="x", alpha=0.2)
        ax.set_axisbelow(True)
        sns.despine(ax=ax)
        fig.tight_layout()
        st.pyplot(fig)
        plt.close(fig)

        # GRAFICO 2: il rapporto evidenzia le categorie sovra-/sotto-rappresentate.
        st.subheader("Tipologie relativamente più o meno rappresentate")
        confronto = res.sort_values("rapporto", ascending=True).copy()
        colori = ["#c2185b" if r >= 1 else "#4d80ae"
                  for r in confronto["rapporto"]]
        fig, ax = plt.subplots(figsize=(10, 5.6))
        fig.patch.set_facecolor("#fffafb")
        ax.set_facecolor("#fffafb")
        ax.barh(confronto["Primary Type"], confronto["rapporto"], color=colori)
        ax.axvline(1, color="#333333", linestyle="--", linewidth=1.3,
                   label="Rapporto = 1 (stessa quota)") #linea tratteggiata verticale per indicare il valore di riferimento 1, cioè stessa quota nel distretto e nella città
        ax.set_xlabel("Rapporto fra quota nel distretto e quota cittadina")
        ax.set_title("Indice di rappresentazione relativa", fontweight="bold")
        ax.legend(loc="best")
        ax.grid(axis="x", alpha=0.2)
        ax.set_axisbelow(True)
        sns.despine(ax=ax)
        fig.tight_layout()
        st.pyplot(fig)
        plt.close(fig)
        st.write("**Come si legge il rapporto?** Se è maggiore di 1, quella tipologia "
                 "occupa una quota più alta nel distretto rispetto alla città; "
                 "se è minore di 1, una quota più bassa.")
        with st.expander("Mostra la tabella completa con i valori"):
            st.dataframe(res, hide_index=True, use_container_width=True)

    st.caption("Il confronto riguarda la composizione dei reati registrati, "
               "non il rischio individuale e non tiene conto della popolazione residente.")


# ----------------------- RANDOM FOREST -----------------------
elif menu == "Predizione Arresto (Random Forest)":
    st.header("Machine Learning: Classificazione degli Arresti")
    st.write("**Domanda:** le informazioni di un evento (tipo, distretto, ora, "
             "giorno e natura domestica) aiutano a riconoscere i casi storici "
             "associati a un arresto?")
    st.caption("Training: 2014–2018 · Test finale: 2019. "
               "La verifica avviene su casi di un anno successivo a quelli di training.")
    if st.button("Addestra e valuta la Random Forest", key="start_rf"):
        with st.spinner("Addestramento e valutazione del modello..."):
            st.session_state.rf_results = st.session_state.back.run_arrest_prediction_advanced(df)
    if "rf_results" in st.session_state:
        result = st.session_state.rf_results
        m = result["metrics"]
        c1, c2, c3 = st.columns(3)
        c1.metric("ROC-AUC", f"{m['ROC-AUC']:.3f}")
        c2.metric("Recall arresto", f"{m['Recall arresto']:.3f}")
        c3.metric("F1 arresto", f"{m['F1 arresto']:.3f}")

        # GRAFICO 1: capire se il modello migliora una scelta banale.
        st.subheader("Accuracy: modello e baseline")
        fig, ax = plt.subplots(figsize=(9, 3.4))
        fig.patch.set_facecolor("#fffafb")
        ax.set_facecolor("#fffafb")
        etichette = ["Baseline (classe più frequente)", "Random Forest"]
        valori = [float(result["baseline_accuracy"]), float(m["Accuracy"])]
        barre = ax.barh(etichette, valori, color=["#4d80ae", "#c2185b"], height=0.48)
        for barra, valore in zip(barre, valori):
            ax.text(min(valore + 0.015, 1.01), barra.get_y() + barra.get_height()/2,
                    f"{valore:.1%}", va="center", fontweight="bold")
        ax.set_xlim(0, 1.12)
        ax.set_xlabel("Accuracy sul test 2019")
        ax.set_title("Confronto con un modello banale", fontweight="bold")
        ax.grid(axis="x", alpha=0.2)
        ax.set_axisbelow(True)
        sns.despine(ax=ax)
        fig.tight_layout()
        st.pyplot(fig)
        plt.close(fig)
        st.caption("La baseline assegna a tutti gli eventi la classe più frequente "
                   "nel training. L'accuracy da sola non basta a valutare la classe arresto.")

        # GRAFICO 2: quadranti TN, FP, FN, TP realmente prodotti dal modello.
        st.subheader("Matrice di confusione")
        c = result["confusion"]
        matrix = pd.DataFrame([[int(c["TN"]), int(c["FP"])],
                               [int(c["FN"]), int(c["TP"])]],
                              index=["Reale: nessun arresto", "Reale: arresto"],
                              columns=["Previsto: nessun arresto", "Previsto: arresto"])
        fig, ax = plt.subplots(figsize=(9, 4.6))
        fig.patch.set_facecolor("#fffafb")
        sns.heatmap(matrix, annot=True, fmt="d", cmap="PuRd", linewidths=1,
                    linecolor="white", cbar=False, ax=ax, annot_kws={"size": 12}) 
        ax.set_title("Predizioni confrontate con gli esiti reali", fontweight="bold")
        ax.set_xlabel("")
        ax.set_ylabel("")
        ax.tick_params(axis="x", rotation=0)
        ax.tick_params(axis="y", rotation=0)
        fig.tight_layout()
        st.pyplot(fig)
        plt.close(fig)
        st.caption("La diagonale contiene le classificazioni corrette; "
                   "le altre due celle rappresentano gli errori.")
        if int(c["TP"]) == 0:
            st.info("Nel test non sono stati individuati correttamente casi di arresto "
                    "con la soglia di classificazione utilizzata. Il recall della classe 1 "
                    "è quindi zero: questo limite va discusso nei risultati.")

        # GRAFICO 3: quali variabili contribuiscono alle decisioni degli alberi.
        st.subheader("Importanza delle caratteristiche")
        importance = pd.DataFrame(result["features"],
                                  columns=["Caratteristica", "Importanza"])
        importance["Importanza"] = pd.to_numeric(importance["Importanza"])
        importance = importance.sort_values("Importanza", ascending=True)
        fig, ax = plt.subplots(figsize=(9, 4))
        fig.patch.set_facecolor("#fffafb")
        ax.set_facecolor("#fffafb")
        ax.barh(importance["Caratteristica"], importance["Importanza"], color="#c2185b")
        ax.set_xlabel("Importanza relativa (Random Forest)")
        ax.set_title("Variabili utilizzate dal modello", fontweight="bold")
        ax.grid(axis="x", alpha=0.2)
        ax.set_axisbelow(True)
        sns.despine(ax=ax)
        fig.tight_layout()
        st.pyplot(fig)
        plt.close(fig)
        st.caption("L'importanza non indica un rapporto di causa-effetto.")

        with st.expander("Mostra tutte le metriche e gli esempi del test"):
            st.write("**Metriche sul test:**")
            st.dataframe(pd.DataFrame([m]), hide_index=True, use_container_width=True)
            st.write("**Matrice di confusione (valori esatti):**")
            st.dataframe(matrix, use_container_width=True)
            st.write("**Esempi dal set di test:**")
            st.dataframe(result["examples"], hide_index=True, use_container_width=True)
        st.caption("Le classi 0 e 1 corrispondono al campo Arrest registrato nel dataset: "
                   "non sono certezze su eventi futuri.")


# ----------------------- CROSS-VALIDATION -----------------------
elif menu == "ML Ottimizzato (Cross-Validation)":
    st.header("Ottimizzazione della Random Forest")
    st.write("Confrontiamo quattro combinazioni di parametri: 10 o 20 alberi "
             "e profondità massima 4 o 6. Usiamo una Cross-Validation a 2 fold "
             "sui dati 2014–2018 e verifichiamo la configurazione scelta sul 2019.")
    if st.button("Esegui la Cross-Validation", key="start_cv"):
        with st.spinner("Valutazione delle quattro configurazioni..."):
            st.session_state.cv_results = st.session_state.back.run_optimized_forest(df)
    if "cv_results" in st.session_state:
        result = st.session_state.cv_results
        st.success(f"Migliore configurazione: {result['best_trees']} alberi, "
                   f"profondità {result['best_depth']}")
        configs = pd.DataFrame(result["configurations"]).copy()
        configs["Configurazione"] = configs.apply(
            lambda r: f"{int(r['Alberi'])} alberi · prof. {int(r['Profondità'])}", axis=1)
        configs = configs.sort_values("ROC-AUC media CV", ascending=True)

        # GRAFICO 1: le quattro configurazioni realmente testate.
        st.subheader("Quale configurazione ha funzionato meglio?")
        colori = ["#c2185b" if (int(r["Alberi"]) == int(result["best_trees"])
                  and int(r["Profondità"]) == int(result["best_depth"]))
                  else "#4d80ae" for _, r in configs.iterrows()]
        fig, ax = plt.subplots(figsize=(10, 4.5))
        fig.patch.set_facecolor("#fffafb")
        ax.set_facecolor("#fffafb")
        barre = ax.barh(configs["Configurazione"],
                        configs["ROC-AUC media CV"], color=colori, height=0.58)
        for barra, valore in zip(barre, configs["ROC-AUC media CV"]):
            ax.text(min(float(valore) + 0.01, 1.01),
                    barra.get_y() + barra.get_height()/2,
                    f"{float(valore):.3f}", va="center", fontweight="bold")
        ax.set_xlim(0, 1.12)
        ax.set_xlabel("ROC-AUC media sui 2 fold")
        ax.set_title("Confronto degli iperparametri", fontweight="bold")
        ax.grid(axis="x", alpha=0.2)
        ax.set_axisbelow(True)
        sns.despine(ax=ax)
        fig.tight_layout()
        st.pyplot(fig)
        plt.close(fig)
        st.caption("Il fucsia evidenzia la configurazione migliore fra quelle provate. "
                   "I punteggi sono calcolati sul training mediante validazione incrociata.")

        # GRAFICO 2: valutazione finale sul test 2019.
        m = result["metrics"]
        c1, c2, c3 = st.columns(3)
        c1.metric("ROC-AUC sul test", f"{m['ROC-AUC']:.3f}")
        c2.metric("Recall arresto", f"{m['Recall arresto']:.3f}")
        c3.metric("F1 arresto", f"{m['F1 arresto']:.3f}")

        metriche = ["ROC-AUC", "Accuracy", "Precision arresto", "Recall arresto", "F1 arresto"]
        # Se è stata eseguita anche la Random Forest base, è possibile
        # effettuare un confronto sullo stesso periodo di test.
        base = st.session_state.get("rf_results")
        st.subheader("Prestazioni sul test 2019")
        fig, ax = plt.subplots(figsize=(10, 4.7))
        fig.patch.set_facecolor("#fffafb")
        ax.set_facecolor("#fffafb")
        pos = list(range(len(metriche)))
        if base is not None:
            ax.barh([p - 0.2 for p in pos],
                    [float(m[x]) for x in metriche], height=0.38,
                    color="#c2185b", label="Random Forest ottimizzata")
            ax.barh([p + 0.2 for p in pos],
                    [float(base["metrics"][x]) for x in metriche], height=0.38,
                    color="#4d80ae", label="Random Forest base")
            ax.legend(loc="lower right")
        else:
            barre = ax.barh(pos, [float(m[x]) for x in metriche],
                            height=0.56, color="#c2185b")
            for barra, x in zip(barre, metriche):
                ax.text(min(float(m[x]) + 0.01, 1.01),
                        barra.get_y() + barra.get_height()/2,
                        f"{float(m[x]):.3f}", va="center")
        ax.set_yticks(pos)
        ax.set_yticklabels(metriche)
        ax.set_xlim(0, 1.13)
        ax.set_xlabel("Punteggio sul test (da 0 a 1)")
        ax.set_title("Valutazione del classificatore", fontweight="bold")
        ax.grid(axis="x", alpha=0.2)
        ax.set_axisbelow(True)
        sns.despine(ax=ax)
        fig.tight_layout()
        st.pyplot(fig)
        plt.close(fig)
        if base is None:
            st.info("Per aggiungere al grafico anche la Random Forest base, "
                    "esegui la sezione 'Predizione Arresto (Random Forest)' nella stessa sessione.")
        with st.expander("Mostra punteggi dettagliati e classificazioni"):
            st.write("**Punteggi medi di Cross-Validation:**")
            st.dataframe(pd.DataFrame(result["configurations"]),
                         hide_index=True, use_container_width=True)
            st.write("**Metriche sul test 2019:**")
            st.dataframe(pd.DataFrame([m]), hide_index=True, use_container_width=True)
            st.write("**Esempi di classificazione:**")
            st.dataframe(result["examples"], hide_index=True, use_container_width=True)
        st.caption("'Ottimizzata' significa migliore tra le quattro configurazioni "
                   "provate, non necessariamente migliore della Random Forest base.")


# ----------------------- PCA -----------------------
elif menu == "Analisi PCA":
    st.header("PCA: Visualizzazione dei Gruppi di Distretti")
    st.write("Usiamo le stesse quattro percentuali territoriali viste nel K-Means. "
             "La PCA le riassume in due componenti, in modo da **visualizzare** "
             "se i distretti dei vari cluster risultano separati.")
    if st.button("Visualizza PCA", key="start_pca"):
        with st.spinner("Calcolo delle componenti principali..."):
            st.session_state.pca_results = st.session_state.back.run_pca_clustering(df)
    if "pca_results" in st.session_state:
        result = st.session_state.pca_results
        st.metric("Varianza spiegata dalle prime 2 componenti",
                  f"{result['explained_variance']:.1%}")
        pdf = result["data"].copy()
        pdf["Cluster"] = pdf["prediction"].apply(lambda n: f"Cluster {int(n)}")
        clusters = sorted(pdf["Cluster"].unique())
        colori_base = ["#c2185b", "#4682b4", "#2a9d8f", "#d49738"]
        palette = {c: colori_base[i % len(colori_base)]
                   for i, c in enumerate(clusters)}

        # GRAFICO 1: proiezione dei distretti nello spazio PC1-PC2.
        st.subheader("Mappa PCA dei distretti")
        fig, ax = plt.subplots(figsize=(10, 6))
        fig.patch.set_facecolor("#fffafb")
        ax.set_facecolor("#fffafb")
        sns.scatterplot(data=pdf, x="PC1", y="PC2", hue="Cluster",
                        palette=palette, s=135, edgecolor="white", linewidth=1,
                        ax=ax)
        for _, row in pdf.iterrows():
            ax.annotate(str(int(row["District"])),
                        (row["PC1"], row["PC2"]), xytext=(5, 5),
                        textcoords="offset points", fontsize=9)
        ax.set_title("Distretti di Chicago nello spazio PCA", fontweight="bold")
        ax.set_xlabel("Prima componente principale (PC1)")
        ax.set_ylabel("Seconda componente principale (PC2)")
        ax.grid(alpha=0.15)
        sns.despine(ax=ax)
        fig.tight_layout()
        st.pyplot(fig)
        plt.close(fig)
        st.caption("I punti vicini hanno caratteristiche territoriali simili nella "
                   "proiezione PCA. Il colore rappresenta il cluster K-Means.")

        # GRAFICO 2: equilibrio del numero di distretti per cluster.
        st.subheader("Quanti distretti contiene ciascun cluster?")
        conteggi = pdf["Cluster"].value_counts().sort_index()
        fig, ax = plt.subplots(figsize=(9, 3.6))
        fig.patch.set_facecolor("#fffafb")
        ax.set_facecolor("#fffafb")
        barre = ax.bar(conteggi.index, conteggi.values,
                       color=[palette[c] for c in conteggi.index], width=0.58)
        for barra, valore in zip(barre, conteggi.values):
            ax.annotate(str(int(valore)),
                        (barra.get_x() + barra.get_width()/2, float(valore)),
                        xytext=(0, 5), textcoords="offset points", ha="center",
                        fontweight="bold")
        ax.set_ylim(0, max(2, float(conteggi.max()) * 1.2))
        ax.set_ylabel("Numero di distretti")
        ax.set_title("Dimensione dei gruppi individuati", fontweight="bold")
        ax.grid(axis="y", alpha=0.2)
        ax.set_axisbelow(True)
        sns.despine(ax=ax)
        fig.tight_layout()
        st.pyplot(fig)
        plt.close(fig)
        st.caption("Questo controllo aiuta a riconoscere eventuali cluster con "
                   "pochissimi distretti, da interpretare con cautela.")

        with st.expander("Mostra coordinate PCA e cluster assegnati"):
            st.dataframe(pdf[["District", "PC1", "PC2", "Cluster"]],
                         hide_index=True, use_container_width=True)
        st.caption("La PCA è una tecnica di visualizzazione e riduzione "
                   "della dimensionalità: non prevede arresti.")


# ----------------------- SERIE TEMPORALE -----------------------
elif menu == "Media Mobile":
    st.header("Trend Temporale (Media Mobile 7gg)")
    st.write("La media mobile attenua le oscillazioni giornaliere: "
             "ogni valore è la media del giorno corrente e dei 6 precedenti.")
    with st.spinner("Calcolo serie temporale..."):
        trend = st.session_state.back.run_time_series_moving_average(df)
    st.line_chart(trend.set_index("dt")[["count", "moving_avg"]])
    st.caption("Vengono mostrati gli ultimi 30 giorni con dati presenti. "
               "È un'analisi descrittiva, non un modello di previsione.")
