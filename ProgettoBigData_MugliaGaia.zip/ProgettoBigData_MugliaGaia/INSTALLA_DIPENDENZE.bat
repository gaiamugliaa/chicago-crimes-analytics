@echo off
setlocal
cd /d "%~dp0"
echo ================================================
echo  PROGETTO BIG DATA - INSTALLAZIONE DIPENDENZE
echo ================================================
py -3.11 --version >nul 2>&1
if errorlevel 1 (
    echo Python 3.11 non trovato. Installa Python 3.11 a 64 bit.
    echo Poi riapri questa finestra.
    pause
    exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
    py -3.11 -m venv .venv
    if errorlevel 1 goto :failed
)
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto :failed
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :failed
echo.
echo Installazione completata. Ora puoi avviare AVVIA_APP.bat
pause
exit /b 0
:failed
echo.
echo Si e' verificato un problema durante l'installazione.
pause
exit /b 1
