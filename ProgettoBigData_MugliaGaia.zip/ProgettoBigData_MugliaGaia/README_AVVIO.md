# ProgettoBigData_MugliaGaia

Applicazione di analisi Chicago Crimes con PySpark (backend) e Streamlit (frontend).

## Contenuto

- `backend.py` - script originale fornito, con i commenti di studio, **non modificato**.
- `main.py` - script originale fornito, con i commenti di studio, **non modificato**.
- `requirements.txt` - dipendenze Python.
- `Materiale_esame/` - presentazione PowerPoint e relazione PDF originali.
- `INSTALLA_DIPENDENZE.bat` - prima installazione, su Windows.
- `AVVIA_APP.bat` - avvio rapido, su Windows.
- `.vscode/` - configurazione facoltativa per Visual Studio Code.

**Il CSV non è incluso.** Estrarre il CSV fornito per il corso nella stessa cartella di `main.py`, chiamandolo esattamente:

`Crimes_-_2001_to_Present.csv`

NON inserire il file in `Materiale_esame/` e NON lasciare soltanto il file ZIP compresso.

## Preparazione consigliata su Windows / Visual Studio Code

1. Installare **Python 3.11 a 64 bit** (attivare l'opzione relativa al PATH, se proposta) e **Java JDK 17**. Spark 3.5.7 funziona con Java 17; verificare `java -version` nel terminale. Se Spark non trova Java, impostare `JAVA_HOME` sulla directory principale del JDK 17 (non su `bin`) e aggiungere `%JAVA_HOME%\bin` al PATH. Riavviare VS Code dopo aver cambiato le variabili d'ambiente.
2. Estrarre lo ZIP e aprire **File > Apri cartella** su `ProgettoBigData_MugliaGaia` in Visual Studio Code.
3. Mettere `Crimes_-_2001_to_Present.csv` accanto a `main.py` e `backend.py`.
4. Per la prima installazione, fare doppio clic su `INSTALLA_DIPENDENZE.bat`; oppure aprire il **terminale integrato di VS Code** e lanciare questi comandi, uno per volta:

   ```bat
   py -3.11 -m venv .venv
   .\.venv\Scripts\python.exe -m pip install --upgrade pip
   .\.venv\Scripts\python.exe -m pip install -r requirements.txt
   ```

   Il comando `py -3.11` richiede una versione Python 3.11 installata. In caso di errore controllare `py --list`.
5. Per avviare, doppio clic su `AVVIA_APP.bat`; **oppure** nel terminale della cartella:

   ```bat
   .\.venv\Scripts\python.exe -m streamlit run main.py
   ```

   Si aprirà il browser (di norma `http://localhost:8501`). Se non si apre automaticamente, copiare l'indirizzo locale riportato nel terminale.
6. Per fermare l'app, premere `Ctrl+C` nel terminale che la sta eseguendo.

**Nota:** i comandi con il percorso `.venv\Scripts\python.exe` funzionano anche senza attivare manualmente l'ambiente virtuale in PowerShell. Se si vuole attivarlo con `Activate.ps1`, PowerShell potrebbe richiedere una policy di esecuzione: non è necessario cambiare la policy se si usa il percorso completo come sopra.

## Controllo prima dell'esame

- Aprire Top 10 e Distribuzione Oraria.
- Aprire Confronto Distretti, selezionare il distretto 11, verificare le due visualizzazioni.
- Calcolare i cluster K-Means e aprire la heatmap.
- Avviare Random Forest base, poi Cross-Validation: in questo ordine è disponibile anche il grafico di confronto.
- Aprire Analisi PCA e Media Mobile.
- Le analisi di ML possono richiedere più tempo e cambiare leggermente nei risultati a seconda della versione/ambiente; fare una prova completa prima della demo.
- Lasciare aperta la sessione del browser se si vogliono riutilizzare i risultati che `st.session_state` conserva.

## Se qualcosa non parte

- `Non trovo il CSV`: il file manca, ha un nome differente, oppure è ancora compresso. Controllare il nome esatto e la posizione.
- `No module named streamlit/pyspark/...`: rilanciare `INSTALLA_DIPENDENZE.bat` o l'installazione dal terminale.
- `Java gateway process exited` / `JAVA_HOME is not set`: verificare di aver installato **JDK 17** e che `java -version` mostri quella versione. Aprire un nuovo terminale dopo l'installazione.
- `Python 3.11 non trovato`: installare Python 3.11 a 64 bit e ricontrollare `py --list`.
- La pagina non compare ma il processo continua: controllare nel terminale l'URL locale, generalmente `http://localhost:8501`.

Non è necessario eseguire `backend.py` direttamente: viene importato e utilizzato da `main.py`. **Non avviare con `python main.py`**, ma con `python -m streamlit run main.py`.
