# QUADRO GENERALE
# Questo file e' il motore del progetto: riceve il DataFrame dei crimini,
# fa i calcoli con Spark e restituisce piccoli risultati che main.py mostra.
# Non disegna i grafici: quelli sono responsabilita' di main.py.
# SparkSession gestisce Spark; Window serve per la media mobile.
# Le librerie pyspark.ml servono per clustering, PCA e classificazione.

from pyspark.sql import SparkSession, Window
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, BooleanType, DoubleType, IntegerType
)
from pyspark.ml import Pipeline
from pyspark.ml.feature import VectorAssembler, StringIndexer, PCA, StandardScaler
from pyspark.ml.functions import vector_to_array
from pyspark.ml.clustering import KMeans
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder
from pyspark.ml.evaluation import BinaryClassificationEvaluator, ClusteringEvaluator


class Backend:

    def __init__(self):
        # Manteniamo l'esecuzione locale: due thread, adatta alla demo sul PC.
        # Spark funziona qui sul mio PC, non su un cluster di computer:
        # - local[2]: mette a disposizione due thread per eseguire i task;
        # - 2g: memoria del driver, che coordina il lavoro;
        # - 8: numero predefinito di partizioni per alcune operazioni di shuffle (quando Spark deve redistribuire dati, per esempio un groupBy).
        # Sono impostazioni contenute per la demo.

        self.spark = (SparkSession.builder
                      .appName("ChicagoCrimes_Analysis")
                      .master("local[2]")
                      .config("spark.driver.memory", "2g")
                      .config("spark.sql.shuffle.partitions", "8")
                      .getOrCreate())
        self.spark.sparkContext.setLogLevel("ERROR")

    # 2) CARICAMENTO E PULIZIA
    # INPUT: path = percorso del CSV su disco.
    # OUTPUT: DataFrame Spark (df) preparato per tutte le analisi.

    def load_data(self, path):
        # Schema esplicito per non dover dedurre i tipi leggendo tutto il CSV.
        # Lo SCHEMA specifica in anticipo il tipo di ciascuna colonna.
        # Il True finale consente valori nulli.

        s = StringType
        crime_schema = StructType([
            StructField("ID", s(), True),
            StructField("Case Number", s(), True),
            StructField("Date", s(), True),
            StructField("Block", s(), True),
            StructField("IUCR", s(), True),
            StructField("Primary Type", s(), True),
            StructField("Description", s(), True),
            StructField("Location Description", s(), True),
            StructField("Arrest", BooleanType(), True),
            StructField("Domestic", BooleanType(), True),
            StructField("Beat", s(), True),
            StructField("District", s(), True),
            StructField("Ward", s(), True),
            StructField("Community Area", s(), True),
            StructField("FBI Code", s(), True),
            StructField("X Coordinate", DoubleType(), True),
            StructField("Y Coordinate", DoubleType(), True),
            StructField("Year", IntegerType(), True),
            StructField("Updated On", s(), True),
            StructField("Latitude", DoubleType(), True),
            StructField("Longitude", DoubleType(), True),
            StructField("Location", s(), True),
        ])

        # Leggiamo il file CSV con Spark. 'header=true' significa che la prima
        # riga contiene i nomi delle colonne. .schema(...) applica i tipi scelti.
        # Un DataFrame Spark e' simile a una tabella, ma Spark puo' elaborarlo
        # in partizioni senza trasferire subito tutto in memoria Python.

        df = (self.spark.read.format("csv")
              .option("header", "true")
              .schema(crime_schema)
              .load(path))

        # Per contenere tempi e memoria prendiamo casualmente CIRCA il 15%.
        # 'seed=42' rende la selezione riproducibile nelle stesse condizioni.
        # I conteggi dei grafici descrittivi riguardano il campione, non tutto il CSV.

        df = df.sample(fraction=0.15, seed=42)
        # .withColumn crea o sostituisce una colonna; F.col("nome") la identifica.
        # Con to_timestamp convertiamo la data da testo a data/ora reale;
        # poi estraiamo ora, mese, giorno della settimana

        df = df.withColumn("Date", F.to_timestamp("Date", "MM/dd/yyyy hh:mm:ss a"))
        df = df.withColumn("Hour", F.hour("Date"))
        df = df.withColumn("Month", F.month("Date"))
        df = df.withColumn("DayOfWeek", F.dayofweek("Date"))
        # Arrest e Domestic partono come valori booleani; li trasformiamo in 1/0 per usarli nel Machine Learning.
        # District viene trasformato in intero per i filtri, ma rimane un CODICE identificativo

        df = df.withColumn("Arrest", F.col("Arrest").cast("int"))
        df = df.withColumn("Domestic", F.col("Domestic").cast("int"))
        df = df.withColumn("District", F.col("District").cast("int"))

        #Elimino gli eventi per cui mancano informazioni essenziali.
        # .dropna elimina solo i casi in cui mancano una delle tre informazioni fondamentali qui elencate.
        # 'RETURN' rimanda il DataFrame al main, che lo passera' agli altri metodi.

        return df.dropna(subset=["Date", "Primary Type", "District"])

    # ---------------------- QUERY AGGREGATE ----------------------
    # Una query aggregata è un'operazione che raggruppa più record sulla base di una caratteristica e calcola una misura riassuntiva.
    # QUERY: I 10 REATI PIU' FREQUENTI
    # groupBy mette insieme le righe della stessa categoria; count le conta.
    # orderBy(desc) ordina dal piu' frequente; limit(10) tiene i primi 10.
    # .toPandas() trasferisce il RISULTATO PICCOLO sul driver per la grafica.
    def get_top_10_crimes(self, df):
        return (df.groupBy("Primary Type").count()
                .orderBy(F.desc("count")).limit(10).toPandas())

    # QUERY: DISTRIBUZIONE NELLE 24 ORE
    # Contiamo quanti crimini hanno Hour=0, Hour=1, ... Hour=23.
    # Ordiniamo le ore in senso crescente per disegnare correttamente la curva.
    # Non e' una previsione: descrive quando sono stati registrati gli eventi.
    def get_hourly_distribution(self, df):
        return (df.groupBy("Hour").count()
                .orderBy("Hour").toPandas())

    # ELENCO DISTRETTI DISPONIBILI NEL MENU
    # Manteniamo solo i distretti con almeno 1000 eventi nel campione;
    # cosi' nel menu del main non compaiono distretti con pochissimi dati.
    # .collect() porta al driver SOLO i codici dei distretti selezionati.
    # Il risultato finale e' una normale lista Python di numeri interi.
    def get_districts(self, df):
        rows = (df.groupBy("District").count()
                .filter((F.col("count") >= 1000) & F.col("District").isNotNull())
                .orderBy("District").select("District").collect())
        return [int(r["District"]) for r in rows]

    # CONFRONTO DISTRETTO - CITTA'
    # INPUT: df e numero del distretto scelto dall'utente nel main.
    # DOMANDA: una certa categoria pesa di piu' o di meno nel distretto rispetto al complesso di Chicago? 
    def get_district_comparison(self, df, district):
        #Confronta la composizione dei reati in un distretto e nell'intera città.
        #Rapporto > 1: una tipologia pesa relativamente di più nel distretto.
        
        # Costruisco due tabelle:
        # - city: quante occorrenze per categoria in TUTTA Chicago campionata;
        # - district_df: quante occorrenze per categoria nel SOLO distretto scelto.

        city = (df.groupBy("Primary Type").count()
                .withColumnRenamed("count", "citta"))
        district_df = (df.filter(F.col("District") == int(district))
                       .groupBy("Primary Type").count()
                       .withColumnRenamed("count", "distretto"))
       
        # join unisce le due tabelle sulla colonna comune, cioè la categoria di reato.
        pdf = district_df.join(city, "Primary Type").toPandas()
        if pdf.empty:
            return pdf
        # Il denominatore distrettuale e' il totale di TUTTI gli eventi del distretto.
        # Il denominatore cittadino deve essere il totale di TUTTA la citta'
        tot_dist = pdf["distretto"].sum()
        # Il join include soltanto i reati presenti nel distretto, quindi per la percentuale cittadina serve il totale completo (non il join).
        tot_city = city.agg(F.sum("citta").alias("n")).first()["n"]
        
        # Per ogni categoria: quota = conteggio categoria / conteggio totale.
        # round(1) arrotonda le percentuali alla prima cifra decimale.
        pdf["% distretto"] = (100 * pdf["distretto"] / tot_dist).round(1)
        pdf["% città"] = (100 * pdf["citta"] / tot_city).round(1)
        pdf["rapporto"] = ((pdf["distretto"] / tot_dist) /
                            (pdf["citta"] / tot_city)).round(2)
        # Mostro le 12 categorie piu' numerose NEL distretto, ordinate.
        # reset_index mette un indice pulito 0,1,2,... per visualizzarle nel main.
        return pdf.sort_values("distretto", ascending=False).head(12).reset_index(drop=True)

    #La media mobile è una tecnica che consente di attenuare le oscillazioni di una serie temporale per osservare meglio l'andamento generale.
    # Non e' Machine Learning: e' una tecnica descrittiva.
    # Invece di guardare soltanto un giorno, facciamo la media degli ultimi 7 conteggi giornalieri. 
    def run_time_series_moving_average(self, df):    
        # Prima trasformiamo ogni timestamp in una semplice data e contiamo
        # quanti eventi sono registrati in ciascun giorno presente nel campione.
        daily = (df.groupBy(F.to_date("Date").alias("dt")).count()
                 .filter(F.col("dt").isNotNull())) 
        # La finestra considera la riga corrente e le SEI precedenti.
        # Sono 7 righe consecutive, non necessariamente 7 giorni di calendario: le date assenti non vengono riempite con zero.
        window = Window.orderBy("dt").rowsBetween(-6, 0) 
        # F.avg(...).over(window) calcola la media SOLO sulle righe della finestra.
        # La nuova colonna moving_avg affianca il conteggio giornaliero originale.
        result = daily.withColumn("moving_avg", F.avg("count").over(window)) 
        # Successivamente prendo le ultime 30 date.
        # Calcoliamo prima la media sull'intera serie e POI mostriamo le ultime
        # 30 date, riordinate dalla piu' vecchia alla piu' recente nel grafico.
        # Cosi' per la prima data mostrata possiamo usare anche giorni precedenti.
        result = result.orderBy(F.desc("dt")).limit(30).orderBy("dt")
        return result.toPandas()

    # ---------------------- CLUSTERING ----------------------
    # REPARAZIONE DEI DISTRETTI PER K-MEANS
    # K-Means NON raggruppa i singoli reati: raggruppa i DISTRETTI.
    # Ogni distretto diventa una sola riga con 4 quote: furti, battery,
    # rapine ed eventi notturni. Manteniamo anche il conteggio totale solo
    # per mostrarlo, NON per calcolare la distanza tra distretti.

    def _district_profiles(self, df):
        # Un distretto = una riga con quattro percentuali interpretabili.
        # .agg consente di calcolare piu' aggregazioni per ciascun distretto.
        profiles = df.groupBy("District").agg(
            F.count("*").alias("total_crimes"),
            F.avg(F.when(F.col("Primary Type") == "THEFT", 1.0)
                  .otherwise(0.0)).alias("quota_furti"),
            F.avg(F.when(F.col("Primary Type") == "BATTERY", 1.0)
                  .otherwise(0.0)).alias("quota_battery"),
            F.avg(F.when(F.col("Primary Type") == "ROBBERY", 1.0)
                  .otherwise(0.0)).alias("quota_rapine"),
            F.avg(F.when((F.col("Hour") >= 20) | (F.col("Hour") < 6), 1.0)
                  .otherwise(0.0)).alias("quota_notte")
        )
        # Scartiamo distretti con meno di 1000 eventi nel campione: quando i record sono pochi, le percentuali possono oscillare molto.
        # Teniamo solo profili completi, senza valori nulli.
        return profiles.filter(F.col("total_crimes") >= 1000).dropna()

    # K-MEANS: SCOPRIRE GRUPPI DI DISTRETTI SIMILI
    # Algoritmo NON supervisionato. Dati K gruppi, assegna i distretti al centroide piu' vicino e aggiorna
    # i centroidi ripetutamente. Cerca gruppi simili per le 4 quote scelte.
    def _cluster_districts(self, df):
        # le 4 feature usate nella distanza tra distretti.
        # Non usiamo total_crimes: altrimenti il cluster potrebbe dipendere soprattutto dal volume degli eventi anziche' dal loro profilo.
        variables = ["quota_furti", "quota_battery", "quota_rapine", "quota_notte"]
        profiles = self._district_profiles(df)
        # Gli algoritmi di Spark ML vogliono un'unica colonna-vettore chiamata(features). VectorAssembler raccoglie 4 colonne in 1 vettore.
        assembler = VectorAssembler(inputCols=variables, outputCol="raw_features")
        data = assembler.transform(profiles)
        # StandardScaler standardizza ogni feature: (valore - media) / dev.std.
        # Perche'? K-Means usa DISTANZE e variabili con diversa dispersione possono pesare in modo sproporzionato. 
        # fit impara medie e deviazioni; transform applica la trasformazione a ogni distretto.
        scaler = StandardScaler(inputCol="raw_features", outputCol="features",
                                withStd=True, withMean=True)
        # .cache() chiede a Spark di tenere questo DataFrame per riusarlo durante
        # i diversi addestramenti con K=2,3,4. count() sotto ne avvia il calcolo.
        # Se restano meno di 4 distretti non proseguiamo: dati insufficienti.
        scaled = scaler.fit(data).transform(data).cache()
        n = scaled.count()
        if n < 4:
            raise ValueError("Troppi pochi distretti per il clustering.")
        # ClusteringEvaluator calcola la SILHOUETTE, una misura di separazione
        # tra cluster: valore alto -> distretti abbastanza vicini nel proprio
        # gruppo e lontani dagli altri. Non basta a garantire cluster "veri".
        # Qui usa, per default, la distanza euclidea al quadrato con clusteringevaluator.
        evaluator = ClusteringEvaluator(featuresCol="features", predictionCol="prediction")
        # Invece di scegliere sempre k=3, confrontiamo poche alternative semplici.
        results = {}
        models = {}
        # Invece di fissare arbitrariamente K, proviamo 2, 3 e 4 cluster.
        # Se K e' >= al numero dei distretti disponibili, quella configurazione viene saltata.
        for k in (2, 3, 4):
            if k >= n:
                continue
            # .fit(scaled) ADDESTRA K-Means su tutti i profili standardizzati.
            # .transform(scaled) assegna a ogni distretto il numero di cluster (colonna 'prediction').
            model = KMeans(k=k, seed=42, featuresCol="features").fit(scaled)
            score = evaluator.evaluate(model.transform(scaled)) #calcola il punteggio per ogni valore di k
            # Salviamo in due dizionari: results contiene K -> silhouette,
            # models contiene K -> modello addestrato. Li useremo per scegliere.
            results[k] = float(score)
            models[k] = model
        # Il numero 0, 1, 2 assegnato ai cluster e' solo un'etichetta: NON e' una classifica di sicurezza dei quartieri.
        best_k = max(results, key=results.get) #Seleziono il valore di K con la Silhouette maggiore tra quelli provati.
        return scaled, models[best_k].transform(scaled), best_k, results

    # CONSEGNA DEI RISULTATI DI K-MEANS AL MAIN
    # Questa e' la funzione chiamata dal pulsante "Calcola i cluster".
    # Riceve cluster, K migliore e punteggi, e prepara una piccola tabella
    # con i distretti e i loro gruppi, adatta ai grafici di Streamlit.
    def run_kmeans(self, df):
        # Riutilizziamo la stessa procedura K-Means per ottenere i cluster.
        # qui i cluster sono ricalcolati, non letti da un grafico.
        # La PCA viene applicata DOPO il clustering per visualizzarlo.
        scaled, clustered, best_k, scores = self._cluster_districts(df)
        columns = ["District", "total_crimes", "quota_furti",
                   "quota_battery", "quota_rapine", "quota_notte", "prediction"]
        # Il risultato ha una riga per distretto, quindi possiamo trasformarlo in Pandas senza portare sul driver tutto l'archivio dei crimini.
        pdf = clustered.select(*columns).orderBy("District").toPandas()
        # La versione standardizzata non serve piu' dopo i calcoli: unpersist() rilascia la persistenza richiesta con cache(), liberando risorse.
        scaled.unpersist()
        # Le quote sono ancora tra 0 e 1: le moltiplichiamo per 100 per mostrare percentuali leggibili. 
        for name in ["quota_furti", "quota_battery", "quota_rapine", "quota_notte"]:
            pdf[name] = (pdf[name] * 100).round(1)
        # Restituiamo un dizionario: main.py userà 'data' per heatmap e scatter,
        # 'best_k' per mostrare il numero scelto e 'silhouette' per il confronto.
        return {"data": pdf, "best_k": best_k, "silhouette": scores}

    # PCA: RAPPRESENTARE I CLUSTER SU UN GRAFICO 2D
    # PCA non crea cluster e NON prevede arresti. Riduce le 4 caratteristiche
    # standardizzate a 2 nuove coordinate PC1 e PC2, conservando quanta più
    # varianza possibile. Quindi il main puo' disegnare un punto per distretto.
    def run_pca_clustering(self, df):
        # PCA sugli stessi quattro profili territoriali del K-Means.
        # Serve a VISUALIZZARE i cluster -> tecnica di riduzione della dimensionalità
        scaled, clustered, best_k, scores = self._cluster_districts(df)
        # Con k=2 chiedo due componenti principali.
        # PC1 cerca la direzione di maggiore varianza, PC2 la successiva(direzione perpendicolare a PC1). 
        # Non sono necessariamente due delle variabili originali, ma loro combinazioni.
        pca = PCA(k=2, inputCol="features", outputCol="pca_features") 
        # fit impara le due direzioni principali; transform proietta ciascun
        # distretto in quelle direzioni. vector_to_array estrae PC1 e PC2 dal
        # vettore di Spark in due colonne, utili per il grafico a dispersione.
        pca_model = pca.fit(scaled)
        projected = pca_model.transform(clustered)
        projected = (projected
                     .withColumn("PC1", vector_to_array("pca_features")[0])
                     .withColumn("PC2", vector_to_array("pca_features")[1]))
        pdf = (projected.select("District", "PC1", "PC2", "prediction")
               .orderBy("District").toPandas())
        # Sommiamo la percentuale di varianza spiegata dalle due componenti.
        variance = float(sum(pca_model.explainedVariance))
        scaled.unpersist()
        # Restituisco coordinate PC1/PC2, cluster e varianza spiegata: sono le informazioni usate nel pannello "Analisi PCA" di Streamlit.
        return {"data": pdf, "best_k": best_k,
                "explained_variance": variance, "silhouette": scores[best_k]}

    # ---------------------- RANDOM FOREST ----------------------
    # PREPARAZIONE DATI PER LA CLASSIFICAZIONE
    # Prevedo l'etichetta 'Arrest' di ogni SINGOLO EVENTO (0=no, 1=si).
    # Usiamo gli stessi esempi per la Random Forest base e quella ottimizzata.
    def _ml_split(self, df):
        # Facciamo  un ulteriore campione del 10%. Poiche' avevamo gia' preso il 15%, resta in media circa l'1,5% degli eventi originali del periodo, prima di eliminare i record incompleti.
        data = (df.filter(F.col("Year").between(2014, 2019))
                .dropna(subset=["Primary Type", "Hour", "District", "Domestic", "Arrest"])
                .withColumn("DistrictStr", F.col("District").cast("string"))
                .sample(fraction=0.10, seed=42))
        
        # TRAIN (2014-2018): esempi con risposta nota, per addestrare il modello.
        # TEST (2019): casi successivi, tenuti separati per valutare se generalizza.
        train = data.filter(F.col("Year") <= 2018).cache()
        test = data.filter(F.col("Year") == 2019).cache()
        # Materializziamo i due campioni prima di riutilizzarli.
        # .count() avvia il calcolo Spark e conta quanti casi abbiamo nei due
        # insiemi. Se uno e' vuoto, fermiamo l'analisi con un messaggio chiaro.
        n_train = train.count()
        n_test = test.count()
        if n_train == 0 or n_test == 0:
            train.unpersist()
            test.unpersist()
            raise ValueError("Nessun evento sufficiente nei periodi train/test.")
        return train, test, n_train, n_test

    @staticmethod
    # PIPELINE DELLA RANDOM FOREST
    # La pipeline e' una catena di operazioni eseguite nello stesso ordine:
    # indicizzo i testi -> preparo un vettore di feature -> alleno la foresta.
    # Questo permette di applicare le stesse trasformazioni anche al test.
    def _rf_pipeline(rf):
        # Type e District sono categorie, non misure quantitative: indicizziamo entrambi.
        # StringIndexer associa a ogni categoria testuale un codice numerico.
        # handleInvalid="keep" gestisce categorie nuove nel test.
        type_indexer = StringIndexer(inputCol="Primary Type", outputCol="TypeIndex",
                                     handleInvalid="keep")
        district_indexer = StringIndexer(inputCol="DistrictStr", outputCol="DistrictIndex",
                                         handleInvalid="keep")
        # VectorAssembler riunisce cinque caratteristiche in una colonna features.
        # Sono gli elementi che la foresta userà per prevedere Arrest.
        # La colonna Arrest NON va nel vettore, altrimenti daremmo al modello la risposta che deve prevedere (data leakage).
        assembler = VectorAssembler(
            inputCols=["TypeIndex", "DistrictIndex", "Hour", "Domestic", "DayOfWeek"],
            outputCol="features", handleInvalid="skip"
        )
        # La pipeline contiene: due StringIndexer, VectorAssembler e RandomForest.
        # Quando farò pipeline.fit(train), Spark addestrerà tutti gli stadi necessari solo sul training, senza imparare le categorie dal test.
        return Pipeline(stages=[type_indexer, district_indexer, assembler, rf])

    @staticmethod
    # VALUTAZIONE DELLA CLASSIFICAZIONE
    # Riceve la tabella con Arrest reale e prediction del modello.
    # L'obiettivo non e' solo contare quanti casi sono corretti, ma anche capire quali errori fa il modello, specie se gli arresti sono rari.
    def _evaluate(predictions):
        # ROC-AUC valuta quanto il modello distingue i casi 1 dai casi 0 considerando diversi valori della soglia decisionale.
        # piu' si avvicina a 1, meglio separa le classi. Non e' una percentuale di predizioni corrette.
        evaluator = BinaryClassificationEvaluator(labelCol="Arrest", metricName="areaUnderROC")
        auc = float(evaluator.evaluate(predictions))
        # Contiamo tutte le combinazioni tra valore REALE e valore PREVISTO.
        # Da queste ricostruiamo la matrice di confusione
        rows = predictions.groupBy("Arrest", "prediction").count().collect()
        # Creiamo un dizionario: per ogni coppia (reale, previsto) salviamo il numero di eventi.
        # .get(...,0) mette zero se una combinazione manca.
        counts = {(int(r["Arrest"]), int(r["prediction"])): r["count"] for r in rows}
        tn = counts.get((0, 0), 0)
        fp = counts.get((0, 1), 0)
        fn = counts.get((1, 0), 0)
        tp = counts.get((1, 1), 0)
        # Calcoliamo metriche complementari:
        # Accuracy = (TP+TN)/tutti: correttezza complessiva.
        # Precision = TP/(TP+FP): tra i previsti arresti, quanti lo erano effettivamente?
        # Recall = TP/(TP+FN): tra gli arresti reali, quanti riconosciuti?
        # F1 = media armonica tra precision e recall.
        # Se il denominatore e' zero, il codice assegna 0 evitando errori.

        n = tn + fp + fn + tp
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        f1 = (2 * precision * recall / (precision + recall)
              if precision + recall else 0.0)
        # Riunisco le metriche in un dizionario che main.py visualizza.
        # '% arresti reali' indica la frequenza della classe 1 nel TEST: serve a capire se una classe e' molto meno frequente dell'altra.
        metrics = {
            "ROC-AUC": round(auc, 3),
            "Accuracy": round((tp + tn) / n, 3) if n else 0.0,
            "Precision arresto": round(precision, 3),
            "Recall arresto": round(recall, 3),
            "F1 arresto": round(f1, 3),
            "% arresti reali": round(100 * (tp + fn) / n, 1) if n else 0.0
        }
        # Prendiamo fino a 15 esempi di eventi nel test, con etichetta reale,
        # previsione e vettore di probabilita'.
        # Queste sono probabilita' stimate dal modello, NON certezze.
        examples = (predictions.select("Primary Type", "Hour", "District",
                                        "Arrest", "probability", "prediction")
                    .limit(15).toPandas())
        if not examples.empty:
            examples["Prob. arresto"] = examples["probability"].apply(
                lambda v: round(float(v[1]), 3))
            examples = examples.drop(columns="probability")
        confusion = {"TN": tn, "FP": fp, "FN": fn, "TP": tp}
        # La funzione restituisce 3 oggetti: punteggi, matrice di confusione e
        # alcuni esempi. Il main li trasformera' in numeri, tabelle e heatmap.
        return metrics, confusion, examples

    # RANDOM FOREST BASE
    # Una Random Forest e' un insieme di alberi decisionali. Ogni albero
    # usa regole sui dati per fare una previsione; la foresta combina
    # le previsioni e spesso è piu' robusta di un solo albero
    def run_arrest_prediction_advanced(self, df):
        train, test, n_train, n_test = self._ml_split(df)
        try:
            # labelCol='Arrest' = RISPOSTA da prevedere (colonna con la risposta resle).
            # featuresCol='features' = DATI usati per prevederla.
            # numTrees=15: 15 alberi; maxDepth=5: limito la complessita';
            # maxBins=64: numero massimo di intervalli per cercare gli split;
            # seed=42: scelta casuale riproducibile in condizioni equivalenti.
            rf = RandomForestClassifier(labelCol="Arrest", featuresCol="features",
                                        numTrees=15, maxDepth=5, maxBins=64, seed=42)
            # La pipeline prepara le feature e addestra la Random Forest con .fit.
            # Poi .transform(test) produce per ciascun evento del 2019 una
            # previsione e i punteggi delle due classi. La colonna 'prediction'
            # contiene 0 o 1, mentre 'probability' contiene i due valori stimati.

            model = self._rf_pipeline(rf).fit(train)
            predictions = model.transform(test).cache()
            try:
                metrics, confusion, examples = self._evaluate(predictions)
            # try/finally garantisce la pulizia dei dati messi in cache anche se qualche operazione solleva un errore. Le risorse vanno liberate.
            finally:
                predictions.unpersist()
            # BASELINE: per capire se il modello fa meglio di una strategia banale,
            # calcoliamo la classe piu' frequente nel TRAIN (spesso 0).
            # Sul TEST misuriamo l'accuracy di un classificatore che risponderebbe
            # SEMPRE con quella classe. ESEMPIO: 80% di classe 0 nel test ->
            # baseline accuracy 0.80 se la classe maggioritaria scelta e' 0.
            train_counts = train.groupBy("Arrest").count().collect()
            majority = max(train_counts, key=lambda r: r["count"])["Arrest"]
            baseline_accuracy = test.filter(F.col("Arrest") == majority).count() / n_test
            # FEATURE IMPORTANCE: quanto ciascuna caratteristica e' stata utile, secondo la misura interna basata sugli split degli alberi.
            feature_names = ["Tipo di reato", "Distretto", "Ora", "Domestic", "Giorno"]
            importance = list(zip(feature_names, model.stages[-1].featureImportances))
            importance.sort(key=lambda item: float(item[1]), reverse=True)
            # Riconsegniamo al main tutto cio' che serve alla pagina Random Forest:
            # metriche, matrice di confusione, esempi, baseline, importanze, quantita' di esempi in training e test.
            return {
                "metrics": metrics, "confusion": confusion, "examples": examples,
                "baseline_accuracy": round(baseline_accuracy, 3),
                "features": importance, "train_count": n_train, "test_count": n_test
            }
        finally:
            train.unpersist()
            test.unpersist()

    # RANDOM FOREST CON RICERCA DEGLI IPERPARAMETRI
    # La foresta base usa valori fissati (15 alberi, profondita' 5).
    # Qui valutiamo alternative e scegliamo la migliore in validazione.
    # 'Iperparametri' = impostazioni scelte PRIMA dell'addestramento.
    def run_optimized_forest(self, df):
        train, test, n_train, n_test = self._ml_split(df)
        try:
            rf = RandomForestClassifier(labelCol="Arrest", featuresCol="features",
                                        maxBins=64, seed=42)
            pipeline = self._rf_pipeline(rf)
            # Due profondità e due numeri di alberi = quattro configurazioni.
            # Costruiamo una griglia di 4 combinazioni:
            # (10 alberi, prof.4), (10,6), (20,4), (20,6).
            # Piu' alberi puo' stabilizzare le previsioni ma costa di piu';
            # piu' profondita' rende il modello flessibile ma rischia overfitting.
            # Non cerchiamo tutte le configurazioni possibili: solo queste quattro.
            grid = (ParamGridBuilder()
                    .addGrid(rf.numTrees, [10, 20])
                    .addGrid(rf.maxDepth, [4, 6])
                    .build())
            # CROSS-VALIDATION A 2 FOLD, solo sui dati di TRAIN:
            # 1) dividiamo il training in due parti;
            # 2) alleniamo sulla prima e valutiamo sulla seconda;
            # 3) scambiamo i ruoli e facciamo la media della ROC-AUC;
            # 4) ripetiamo tutto per ciascuna delle quattro configurazioni.
            # parallelism=1 evita piu' addestramenti in parallelo sul PC locale.
            cv = CrossValidator(
                estimator=pipeline, estimatorParamMaps=grid,
                evaluator=BinaryClassificationEvaluator(labelCol="Arrest",
                                                        metricName="areaUnderROC"),
                numFolds=2, seed=42, parallelism=1)
            # fit esegue la selezione tramite CV, poi riaddestra il modello migliore
            # su tutto il training. Il test 2019 NON partecipa alla scelta.
            # transform(test) permette la valutazione finale su un anno successivo.
            cv_model = cv.fit(train)
            predictions = cv_model.transform(test).cache()
            try:
                metrics, confusion, examples = self._evaluate(predictions)
            finally:
                predictions.unpersist()
            # Recupero l'ultimo stadio (Random Forest) della pipeline scelta,
            # per conoscere quanti alberi e quale profondita' sono stati selezionati.
            chosen = cv_model.bestModel.stages[-1]
            # Preparo una tabella per il main: per ogni configurazione riporto
            # numero di alberi, profondita' e ROC-AUC media sui due fold.
            # Questo rende visibile PERCHE' una configurazione e' stata preferita.
            table = []
            for params, score in zip(grid, cv_model.avgMetrics):
                table.append({
                    "Alberi": params[rf.numTrees],
                    "Profondità": params[rf.maxDepth],
                    "ROC-AUC media CV": round(float(score), 3)
                })
            return {
                "metrics": metrics, "confusion": confusion, "examples": examples,
                "configurations": table,
                "best_trees": chosen.getNumTrees,
                "best_depth": chosen.getOrDefault(chosen.maxDepth),
                "train_count": n_train, "test_count": n_test
            }
        finally:
            train.unpersist()
            test.unpersist()
