@echo off
setlocal
cd /d "%~dp0"
if not exist "Crimes_-_2001_to_Present.csv" (
  echo Manca Crimes_-_2001_to_Present.csv nella cartella del progetto.
  echo Copia il CSV estratto accanto a main.py e backend.py.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  echo Prima esegui INSTALLA_DIPENDENZE.bat
  pause
  exit /b 1
)
echo Avvio l'applicazione Streamlit...
".venv\Scripts\python.exe" -m streamlit run main.py
if errorlevel 1 (
  echo L'app si e' chiusa con un errore. Leggi le righe precedenti.
  pause
)
